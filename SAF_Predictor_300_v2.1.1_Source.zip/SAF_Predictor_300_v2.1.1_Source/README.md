# SAF-Predict 300

English-language Windows desktop preview for hydrocarbon property prediction.

All seven property models are trained and available in version 2.1.1. Y02 uses its own SVR, trained directly on X01–X07 and the existing numeric Y02 reference values in the supplied workbook, as confirmed by the user. Y02 is never computed by multiplying the Y01 and Y03 predictions. Native execution on Windows has not yet been tested.

## Start on Windows

Extract the complete `SAF_Predictor_300_Windows_EN.zip` archive, then double-click `SAF_Predictor_300.exe`. Keep the `_internal` directory beside the executable. Do not run the executable inside the ZIP archive. Python installation and an internet connection are not required at runtime.

All application labels, menus, property names, messages, generated export fields, and this guide are in English. User-entered molecule names and original source records retain their supplied text. The original workbook and its reference transcription are preserved for provenance.

## Features

- **Single Prediction:** enter X01–X07, or enter SMILES and choose **Calculate from SMILES**. Click **Predict Properties**, then export results as CSV or JSON.
- **Batch Prediction:** import CSV, TSV, or XLSX with all seven descriptor columns or a SMILES column. Each row retains its results or error message. Batches are limited to 10,000 rows; the table displays the first 1,000, while exports include every row. If both SMILES and descriptors are present, they must agree.
- **Validation Examples menu:** load any of the eight held-out molecules directly, then click **Predict Properties**.
- **Molecule Library:** search 308 records by name, CAS, formula, or record ID. The table contains dataset reference values. Double-click a molecule to load its inputs for prediction.
- **Models & Validation:** inspect grouped cross-validation and held-out validation metrics for each property.
- **Local Feature Contributions:** after predicting, select a property and click **Explain**. Exact interventional Shapley contributions use all 128 subsets of seven inputs and a fixed background of 12 modeling molecules. Contributions plus the baseline equal the deployed model prediction. They do not represent causal effects or prediction error.

Keyboard shortcuts: Ctrl+D loads an example, Ctrl+Enter predicts, Ctrl+E explains, Ctrl+O imports a batch, Ctrl+S exports the current result, and Ctrl+1–4 switches pages. The macOS development preview also supports Command equivalents.

## Inputs and outputs

| Input | Definition |
|---|---|
| X01 | Molar mass, g/mol; RDKit MolWt |
| X02 | Hydrogen-to-carbon atomic ratio |
| X03 | Aromatic carbon atoms / total carbon atoms, 0–1 |
| X04 | RDKit CalcNumRings, including its ring-count convention for bridged structures |
| X05 | Number of carbon atoms directly connected to at least three other carbon atoms |
| X06 | ln(1+n), where n is the graph automorphism count ignoring stereochemistry; not the external rotational symmetry number σ |
| X07 | Second-order Kier shape index, κ₂ |

| Output | Model | Unit |
|---|---|---|
| Y01 Mass-based net heat of combustion (NHOC) | Random Forest | MJ/kg |
| Y02 Volumetric net heat of combustion (NHOC) | Independent SVR | MJ/L |
| Y03 Density | SVR | g/cm³ |
| Y04 Pure-component solid–liquid transition temperature | XGBoost | °C |
| Y05 Boiling point | SVR | °C |
| Y06 Flash point | SVR | °C |
| Y07 Kinematic viscosity at 40°C | SVR | mm²/s |

The application supports neutral, closed-shell hydrocarbons without isotope labels. Identical seven-descriptor inputs produce identical predictions, so the model cannot distinguish every isomer. Outputs support research screening and do not certify a finished aviation fuel.

## Dataset and validation protocol

The supplied `SAF_Hydrocarbon_3Sheet_XY01-07_Beautified (1).xlsx` is preserved as `data/source_dataset.xlsx`.

Sheet1 contains the 300 modeling molecules, organized into 73 molecular-formula groups. Original Sheet2 records T02 (HC-0002) and T08 (HC-0103) are excluded. The other eight records are reserved for validation and displayed as T01–T08; `original_test_id` in `data/validation.csv` preserves their original identifiers. Excluded records have not been moved into training.

Each property uses a fixed RF, SVR, or XGBoost model family. Nested GroupKFold uses five outer folds and three inner folds, grouped by molecular formula, with inner RMSE minimization. SVR input and output scaling is fitted within each training fold. Final hyperparameters are selected by a separate three-fold grouped search on the 300 modeling records, followed by a fit on all 300. The eight holdout records are not used for fitting, tuning, model selection, or threshold calibration.

These models were fitted from the current workbook. They are separate from the historical frozen predictor that used 205 fitting records and 95 calibration records. This preview reports computed point predictions, evaluation metrics, and a continuous descriptor-distance percentile. It does not reuse historical prediction intervals or provide calibrated intervals for individual molecules.

Seven of the eight holdout molecular formulas occur in the modeling set, although no connectivity identities or complete descriptor vectors overlap. The evaluation is therefore an internal holdout assessment. Property references have mixed experimental, database, calculated, and estimated origins; they are not all independent measurements. Y04 holdout R² is negative in the current evaluation, so transition-temperature predictions require particular care in screening.

**Y02 reference values and independent prediction:** the workbook stores Y02 reference values as cached results of Excel multiplication formulas (`=P5*R5`, for example). The user explicitly approved using those existing numeric labels to train a separate SVR. Training uses only X01–X07 as predictors; neither Y01 nor Y03 is an input to the Y02 model. Its five-fold outer / three-fold inner grouped evaluation and eight-molecule holdout evaluation use the same protocol as the other targets. The labels remain calculated references, not independent experimental measurements. This source-specific decision is recorded in `data/training_policy.json` and bound to the workbook SHA-256.

## Reproduce from source

Create a Python 3.12 environment and install `requirements-training.txt`. Launch the source application with `python run_app.py`.

```text
python run_cli.py --input data/validation.csv --output predictions.csv
python run_cli.py --smiles CCCCCCCCCC
python tests/test_app.py
```

Preparing data again rebuilds the manifest and invalidates the model listing. Follow preparation with training; existing model files must not be treated as newly trained results.

```text
python training/prepare_data.py data/source_dataset.xlsx
python training/train.py --targets Y01 Y02 Y03 Y04 Y05 Y06 Y07 --jobs 2
```

`reports/` contains the data audit, fold predictions, holdout predictions, selected parameters, and verification logs. The `training/*.joblib` files preserve training estimators for reproducibility. The application itself loads SHA-256-checked JSON models and does not load pickle files.

## Windows package and verification status

This package reuses the user-supplied V10 Windows 64-bit interpreter and bootloader. The application entry, descriptors, inference models, interface, and data have been replaced. The V10 model cache is removed. Windows dependencies, including RDKit, come from official PyPI wheels; source URLs and checksums are recorded in `build_info.json`.

The Windows PE launcher, Python 3.12 entry bytecode, Tk modules, packaged dependencies, and model checksums have been inspected. Desktop functionality and numerical consistency have been tested on the development machine. The registered Windows VM is on a disconnected disk, so Windows-native startup has not been verified. This is a development preview, not a Windows-validated final release.

The seven-model package supports this Windows self-test:

```text
SAF_Predictor_300.exe --self-test "%TEMP%\SAF_self_test.json"
```

Startup errors are logged to `%LOCALAPPDATA%\SAF-Predict-300\startup_error.log`.

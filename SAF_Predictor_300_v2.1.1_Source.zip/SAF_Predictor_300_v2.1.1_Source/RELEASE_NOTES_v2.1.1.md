# SAF-Predict 300 v2.1.1 — English Windows desktop preview

This release archives the supplied Windows application and its corresponding Python source, seven fitted models, training workflow, current workbook, and evaluation records.

## Downloads

- [Windows application](https://github.com/Wangwuyu-hub/saf-predictor-V1/releases/download/v2.1.1/SAF_Predictor_300_Windows_EN.zip): extract the entire ZIP and run `SAF_Predictor_300.exe`. Keep `_internal` beside it.
- [Source and reproducibility package](https://github.com/Wangwuyu-hub/saf-predictor-V1/releases/download/v2.1.1/SAF_Predictor_300_v2.1.1_Source.zip): application source, data, portable JSON models, fitted Joblib estimators, training scripts, tests, and archived predictions.
- [Asset checksums](https://github.com/Wangwuyu-hub/saf-predictor-V1/releases/download/v2.1.1/release-assets-v2.1.1.sha256).

## Models and data

The Windows application uses 300 modeling molecules and eight internal holdout molecules. Original Sheet2 T02 and T08 are excluded. The remaining holdout records are renumbered T01–T08; the original identifiers are retained in `data/validation.csv`.

All seven property models are fitted. Y01 uses RF, Y02/Y03/Y05/Y06/Y07 use SVR, and Y04 uses XGBoost. Y02 has its own SVR using X01–X07; it does not multiply the Y01 and Y03 predictions. The supplied workbook's cached numeric Y02 labels are calculated references, explicitly approved for this training run and documented in `data/training_policy.json`.

Nested cross-validation uses five outer and three inner molecular-formula-grouped folds. The eight holdout molecules are excluded from fitting and tuning. The current holdout Y04 R² is −0.143 and MAE is 30.73 °C; these results limit its screening use. This is an internal assessment, not external experimental validation or aviation-fuel certification.

This Windows release is a separate modeling snapshot from the v1.1.0 browser release, which uses a different Y02 label set and model. Do not combine their datasets, model artifacts, predictions, or metrics. Historical releases and the browser branch remain available.

## Interface

The English desktop interface supports single and batch prediction, SMILES descriptor calculation, a 308-molecule library, model metrics, CSV/JSON export, local feature contributions, and a Validation Examples menu for all eight holdout molecules.

## Verification status

The supplied Windows ZIP is preserved byte for byte (295,675,065 bytes; SHA-256 `c22af6b1a3677f7a978f4045d519eb59357cd9002115ab96cc5062126ab1fe9c`). The archive CRC, Windows PE launcher structure, packaged source, seven model hashes, data split, numerical inference, independent Y02 path, and archived metrics have been checked. Ten behavioral and numerical tests passed on the development machine.

Windows-native startup and GUI execution have not yet been verified. This release is therefore marked as a prerelease. `reports/package_verification.json` records that limitation. After extraction on Windows, the package provides:

```text
SAF_Predictor_300.exe --self-test "%TEMP%\SAF_self_test.json"
```

## Source and build reproduction

Use Python 3.12, install `requirements-training.txt`, and follow `README.md` to launch, test, or retrain. `FILE_MANIFEST.json` lists the published source snapshot's individual file hashes. Transient logs, dependency caches, virtual environments, and manuscript drafts are not included.

`packaging/build_windows.py` assembles the Windows distribution using the original V10 Windows archive as an external runtime input:

```text
python packaging/build_windows.py --legacy path/to/SAF_V10_Predictor_Windows.zip
python packaging/verify_release.py dist/SAF_Predictor_300_Windows_EN
```

The V10 input archive is not part of this source snapshot. Its SHA-256 and the official dependency download URLs are recorded in the Windows package's `build_info.json`. Running the source and reproducing predictions/training do not require that legacy archive. A bit-for-bit rebuild is not promised.

The existing MIT software license is retained. Third-party libraries and source records remain subject to their original terms; the MIT software license does not relicense the supplied reference workbook.

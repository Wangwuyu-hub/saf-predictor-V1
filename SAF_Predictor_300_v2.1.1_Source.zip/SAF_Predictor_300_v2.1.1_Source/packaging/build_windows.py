"""Rebuild the user's existing CPython-3.12 PyInstaller Windows distribution.

Reuses the supplied Windows bootloader, PYZ and DLL runtime. Replaces its
application entry and removes the old model. This is archive assembly, not
a claim that PyInstaller supports cross-compilation. All new inference is
portable Python and inspected JSON; Windows RDKit/Pillow wheels are from PyPI.
"""
import argparse
import hashlib
import json
import marshal
import shutil
import ssl
import struct
import sys
import sysconfig
import urllib.request
import zipfile
import zlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CACHE=ROOT/'packaging/downloads'
CONTEXT=ssl.create_default_context(cafile='/etc/ssl/cert.pem') if Path('/etc/ssl/cert.pem').exists() else ssl.create_default_context()


def download(url,path,expected=None):
    if path.exists() and (not expected or hashlib.sha256(path.read_bytes()).hexdigest()==expected):return
    with urllib.request.urlopen(url,context=CONTEXT,timeout=90) as r:data=r.read()
    if expected and hashlib.sha256(data).hexdigest()!=expected:raise ValueError('Download checksum mismatch')
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)


def wheel(name,version):
    with urllib.request.urlopen(f'https://pypi.org/pypi/{name}/{version}/json',context=CONTEXT,timeout=60) as r:meta=json.load(r)
    options=[x for x in meta['urls'] if x['filename'].endswith('.whl') and ('cp312-cp312-win_amd64' in x['filename'] or 'py3-none-any' in x['filename'] or 'py2.py3-none-any' in x['filename'])]
    if len(options)!=1:raise ValueError((name,[x['filename'] for x in options]))
    item=options[0];path=CACHE/item['filename'];download(item['url'],path,item['digests']['sha256'])
    return path,{'name':name,'version':version,'url':item['url'],'sha256':item['digests']['sha256']}


def repack(exe,entry):
    cookie=exe.rfind(b'MEI\014\013\012\013\016')
    magic,total,pos,toclen,version,lib=struct.unpack('!8sIIII64s',exe[cookie:cookie+88])
    assert version==312 and sys.version_info[:2]==(3,12), 'Use Python 3.12 for Windows bytecode.'
    start=cookie+88-total;toc=exe[start+pos:start+pos+toclen]
    rows=[];i=0;replaced=False
    while i<len(toc):
        size,off,clen,ulen,flag,kind=struct.unpack('!iIIIBc',toc[i:i+18]);name=toc[i+18:i+size].rstrip(b'\0').decode()
        payload=exe[start+off:start+off+clen]
        if name=='app_v10':
            raw=marshal.dumps(compile(entry,'saf_desktop_entry.py','exec'))
            payload=zlib.compress(raw,9);clen=len(payload);ulen=len(raw);flag=1;name='saf_desktop_entry';replaced=True
        rows.append((name,kind,payload,ulen,flag));i+=size
    assert replaced
    payloads=bytearray();newtoc=bytearray()
    for name,kind,data,ulen,flag in rows:
        off=len(payloads);payloads.extend(data)
        n=name.encode()+b'\0';length=((18+len(n)+15)//16)*16
        newtoc.extend(struct.pack('!iIIIBc',length,off,len(data),ulen,flag,kind));newtoc.extend(n+b'\0'*(length-18-len(n)))
    tocpos=len(payloads);payloads.extend(newtoc)
    payloads.extend(struct.pack('!8sIIII64s',magic,len(payloads)+88,tocpos,len(newtoc),version,lib))
    # The supplied PE has no Authenticode signature; retain its bootloader bytes.
    peoff=struct.unpack('<I',exe[0x3c:0x40])[0];assert exe[peoff:peoff+4]==b'PE\0\0'
    return exe[:start]+payloads


def build(legacy,allow_pending=False):
    manifest=json.loads((ROOT/'models/manifest.json').read_text(encoding='utf-8'))
    if len(manifest['models'])!=7 and not allow_pending:raise RuntimeError('Final release requires all seven models.')
    name='SAF_Predictor_300_Windows_EN' if len(manifest['models'])==7 else 'SAF_Predictor_300_Preview_EN'
    dest=ROOT/'dist'/name;dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(legacy) as z:
        for item in z.infolist():
            rel=Path(*Path(item.filename).parts[1:])
            if not rel.parts or '..' in rel.parts or item.is_dir():continue
            if rel.name=='ml_cache_v10_app.pkl':continue
            if rel.suffix.lower()=='.exe' and len(rel.parts)==1:
                data=repack(z.read(item),(ROOT/'packaging/windows_entry.py').read_text(encoding='utf-8'))
                (dest/'SAF_Predictor_300.exe').write_bytes(data)
            else:
                out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True)
                if not out.exists():out.write_bytes(z.read(item))
    vendor=dest/'_internal/vendor';vendor.mkdir(parents=True,exist_ok=True)
    # The legacy PYZ lacks tkinter.font. Vendor the complete portable stdlib package.
    shutil.copytree(Path(sysconfig.get_path('stdlib'))/'tkinter',vendor/'tkinter',dirs_exist_ok=True,
                    ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    deps=[]
    for package,version in [('rdkit','2025.9.2'),('pillow','11.3.0'),('openpyxl','3.1.5'),('et-xmlfile','2.0.0')]:
        p,info=wheel(package,version);deps.append(info)
        with zipfile.ZipFile(p) as z:z.extractall(vendor)
    stdlib=CACHE/'python-3.12.10-embed-amd64.zip'
    download('https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip',stdlib)
    with zipfile.ZipFile(stdlib) as z:
        (vendor/'python312.zip').write_bytes(z.read('python312.zip'))
        # Keep the original DLL/runtime version; add only missing standard extension modules.
        for n in z.namelist():
            if n.endswith('.pyd') and not (dest/'_internal'/n).exists():(dest/'_internal'/n).write_bytes(z.read(n))
    app=dest/'_internal/application';app.mkdir(parents=True,exist_ok=True)
    build_reports=('package_verification.json','windows_build.log','preview_build.log')
    for filename in build_reports:
        (app/'reports'/filename).unlink(missing_ok=True)
    for d in ('src','models','data','reports'):
        shutil.copytree(ROOT/d,app/d,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','training.log','._*','.DS_Store',*build_reports))
    for filename in ('README.md',):
        if (ROOT/filename).exists():shutil.copy2(ROOT/filename,dest/filename)
    buildinfo={'legacy_zip_sha256':hashlib.sha256(legacy.read_bytes()).hexdigest(),
               'strategy':'Reused user-supplied native Windows CPython 3.12 runtime; replaced application entry and removed V10 model.',
               'python_bytecode_version':sys.version.split()[0],'windows_architecture':'x86_64',
               'native_windows_tested':False,'interface_language':'en','new_wheels':deps,
               'stdlib_url':'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip',
               'stdlib_download_sha256':hashlib.sha256(stdlib.read_bytes()).hexdigest()}
    (dest/'build_info.json').write_text(json.dumps(buildinfo,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=ROOT/'dist'/f'{name}.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(dest.rglob('*')):
            if p.is_file() and not p.name.startswith('._') and p.name!='.DS_Store':z.write(p,p.relative_to(dest.parent))
    print(json.dumps({'folder':str(dest),'zip':str(archive),'zip_bytes':archive.stat().st_size},ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--legacy',type=Path,required=True);p.add_argument('--allow-pending-preview',action='store_true')
    a=p.parse_args();build(a.legacy,a.allow_pending_preview)

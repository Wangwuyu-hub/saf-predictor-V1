"""Read-only package integrity and application/runtime checks."""
import hashlib
import json
import marshal
import struct
import sys
import zipfile
import zlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def verify(folder):
    expected=ROOT/'src'
    app=folder/'_internal/application'
    for p in expected.rglob('*.py'):
        if p.name.startswith('._'):continue
        copied=app/'src'/p.relative_to(expected)
        assert p.read_bytes()==copied.read_bytes(),f'Stale package code: {copied}'
    assert (folder/'README.md').read_bytes()==(ROOT/'README.md').read_bytes()
    assert json.loads((folder/'build_info.json').read_text())['interface_language']=='en'
    assert (folder/'_internal/vendor/tkinter/font.py').exists()
    assert (folder/'_internal/vendor/rdkit/rdBase.pyd').exists()
    assert not (folder/'_internal/ml_cache_v10_app.pkl').exists()
    b=(folder/'SAF_Predictor_300.exe').read_bytes();cookie=b.rfind(b'MEI\014\013\012\013\016')
    _,size,pos,length,version,lib=struct.unpack('!8sIIII64s',b[cookie:cookie+88]);start=cookie+88-size;toc=start+pos;entry=None;names=[]
    assert version==312 and sys.version_info[:2]==(3,12)
    assert b[:2]==b'MZ'
    while toc<start+pos+length:
        n,off,clen,ulen,flag,kind=struct.unpack('!iIIIBc',b[toc:toc+18]);name=b[toc+18:toc+n].rstrip(b'\0').decode();names.append(name)
        if name=='saf_desktop_entry':entry=marshal.loads(zlib.decompress(b[start+off:start+off+clen]))
        toc+=n
    assert entry and entry.co_filename=='saf_desktop_entry.py'
    assert 'app_v10' not in names
    m=json.loads((app/'models/manifest.json').read_text(encoding='utf-8'))
    assert m==json.loads((ROOT/'models/manifest.json').read_text(encoding='utf-8'))
    assert set(m['models'])==set(m['metrics'])
    for t,meta in m['models'].items():assert hashlib.sha256((app/f'models/{t}.json.gz').read_bytes()).hexdigest()==meta['sha256']
    if len(m['models'])==7:
        assert m['models']['Y02']['family']=='SVR' and m['models']['Y02']['fit_n']==300
        assert m['metrics']['Y02']['cv']['n']==300 and m['metrics']['Y02']['validation']['n']==8
    archive=folder.with_suffix('.zip')
    with zipfile.ZipFile(archive) as z:
        assert not z.testzip()
        assert not any(Path(n).name.startswith('._') for n in z.namelist())
    result={'status':'preview_integrity_pass' if len(m['models'])<7 else 'package_integrity_pass',
            'interface_language':'en','model_count':len(m['models']),'development_n':m['development_n'],'validation_n':m['validation_n'],
            'exe_format':'PE Windows x86_64 / CPython 3.12','source_matches_packaged_files':True,
            'archive_crc_verified':True,'old_v10_model_removed':True,
            'native_windows_execution_tested':False,'Y02_status':m['Y02_source_status'],
            'zip_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'zip_bytes':archive.stat().st_size}
    (ROOT/'reports/package_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':verify(Path(sys.argv[1]))

"""Entry script compiled with CPython 3.12 for the existing Windows bootloader."""
import os
import sys
from pathlib import Path

INTERNAL=Path(sys._MEIPASS)
ROOT=INTERNAL/'application'
sys.path.insert(0,str(INTERNAL/'vendor'))
sys.path.insert(0,str(INTERNAL/'vendor/python312.zip'))
sys.path.insert(0,str(ROOT/'src'))
if hasattr(os,'add_dll_directory'):
    _dll_dirs=[]
    for path in (INTERNAL/'vendor/rdkit.libs',INTERNAL/'vendor/PIL',INTERNAL):
        if path.is_dir():_dll_dirs.append(os.add_dll_directory(str(path)))

try:
    if '--self-test' in sys.argv:
        import json
        from saf_app.engine import Predictor
        from saf_app.descriptors import from_smiles
        predictor=Predictor(ROOT)
        features,_=from_smiles('CCCCCCCCCC')
        result=predictor.predict(features)
        assert len(result['outputs'])==7, 'All seven property models must be present.'
        result['status']='pass'
        path=Path(sys.argv[sys.argv.index('--self-test')+1])
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    else:
        from saf_app.gui import main
        main(ROOT)
except Exception:
    import traceback
    logdir=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'SAF-Predict-300'
    logdir.mkdir(parents=True,exist_ok=True)
    log=logdir/'startup_error.log'
    log.write_text(traceback.format_exc(),encoding='utf-8')
    if '--self-test' not in sys.argv:
        import tkinter as tk
        from tkinter import messagebox
        r=tk.Tk();r.withdraw()
        messagebox.showerror('SAF-Predict Startup Failed',f'Keep the extracted application directory intact.\nError log: {log}');r.destroy()
    raise

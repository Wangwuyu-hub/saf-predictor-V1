import os
import sys
from pathlib import Path

ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
sys.path.insert(0,str(ROOT/'src'))
from saf_app.gui import main

if __name__=='__main__':
    main(ROOT)

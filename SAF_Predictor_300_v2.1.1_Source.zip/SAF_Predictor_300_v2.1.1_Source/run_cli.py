"""Batch/API entry point using the same inference engine as the desktop app."""
import argparse
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from saf_app.engine import Predictor,read_batch,predict_batch,write_csv
from saf_app.descriptors import from_smiles

if __name__=='__main__':
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--input',type=Path);g.add_argument('--smiles');p.add_argument('--output',type=Path)
    a=p.parse_args();predictor=Predictor(ROOT)
    if a.smiles:
        features,identity=from_smiles(a.smiles);result={**identity,**predictor.predict(features)}
        text=json.dumps(result,ensure_ascii=False,indent=2)
        if a.output:a.output.write_text(text,encoding='utf-8')
        else:print(text)
    else:
        if not a.output:p.error('--input requires --output')
        rows=predict_batch(predictor,read_batch(a.input));write_csv(a.output,rows)
        print(json.dumps({'rows':len(rows),'errors':sum(r['status']=='error' for r in rows),'output':str(a.output)}))

"""SAF-Predict desktop application."""
__version__ = '2.0.0'

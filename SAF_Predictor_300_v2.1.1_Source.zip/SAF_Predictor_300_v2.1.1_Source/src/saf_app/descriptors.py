"""Descriptor definitions match the supplied workbook, including RDKit ring count."""
import math


def from_smiles(smiles):
    from rdkit import Chem
    from rdkit.Chem import Descriptors, GraphDescriptors, rdMolDescriptors
    mol = Chem.MolFromSmiles(smiles.strip())
    if mol is None or not mol.GetNumAtoms():
        raise ValueError('Unable to parse SMILES. Check the molecular structure.')
    mol = Chem.RemoveHs(mol)
    if len(Chem.GetMolFrags(mol)) != 1:
        raise ValueError('Enter a single molecule. Dot-separated mixtures and salts are not supported.')
    if any(a.GetAtomicNum() != 6 or a.GetFormalCharge() or a.GetNumRadicalElectrons()
           or a.GetIsotope() for a in mol.GetAtoms()):
        raise ValueError('This model supports only neutral, closed-shell hydrocarbons without isotope labels.')
    atoms = list(mol.GetAtoms())
    carbon = len(atoms)
    graph = Chem.MolFromSmiles(Chem.MolToSmiles(mol, isomericSmiles=False))
    automorphisms = len(graph.GetSubstructMatches(graph, uniquify=False, maxMatches=100000))
    if automorphisms >= 100000:
        raise ValueError('The graph automorphism count exceeds the calculation limit; X06 cannot be computed accurately.')
    x = [Descriptors.MolWt(mol), sum(a.GetTotalNumHs(includeNeighbors=True) for a in atoms) / carbon,
         sum(a.GetIsAromatic() for a in atoms) / carbon, rdMolDescriptors.CalcNumRings(mol),
         sum(sum(n.GetAtomicNum() == 6 for n in a.GetNeighbors()) >= 3 for a in atoms),
         math.log1p(automorphisms), GraphDescriptors.Kappa2(mol)]
    return dict(zip([f'X{i:02}' for i in range(1, 8)], map(float, x))), {
        'smiles': Chem.MolToSmiles(mol), 'formula': rdMolDescriptors.CalcMolFormula(mol),
        'inchikey': Chem.MolToInchiKey(mol),
    }

"""Portable numerical inference. No pickles or runtime model fitting.

Y02 is always read from its own model. It is never a product of predictions.
"""
import bisect
import csv
import gzip
import hashlib
import itertools
import json
import math
import struct
from pathlib import Path
from .schema import FEATURES, TARGETS, OUTPUTS


def f32(value):
    return struct.unpack('f', struct.pack('f', value))[0]


def predict_model(model, x):
    if model['kind'] == 'svr':
        z = [(v - m) / s for v, m, s in zip(x, model['x_mean'], model['x_scale'])]
        value = model['intercept'] + sum(
            c * math.exp(-model['gamma'] * sum((a - b) ** 2 for a, b in zip(z, sv)))
            for c, sv in zip(model['dual_coef'], model['support_vectors']))
        return value * model['y_scale'] + model['y_mean']
    xf = list(map(f32, x))
    if model['kind'] == 'rf':
        value = 0.0
        for tree in model['trees']:
            node = 0
            while tree['left'][node] != -1:
                node = tree['left'][node] if xf[tree['feature'][node]] <= tree['threshold'][node] else tree['right'][node]
            value += tree['value'][node]
        return value / len(model['trees'])
    if model['kind'] == 'xgb':
        value = f32(model['base_score'])
        for tree in model['trees']:
            node = 0
            while tree['left'][node] != -1:
                node = tree['left'][node] if xf[tree['feature'][node]] < f32(tree['threshold'][node]) else tree['right'][node]
            value = f32(value + f32(tree['threshold'][node]))
        return float(value)
    raise ValueError('Unknown model format.')


def validate(row):
    values = []
    for code in FEATURES:
        try:
            raw = row[code]
            if isinstance(raw, bool) or raw is None or str(raw).strip() == '':
                raise ValueError()
            value = float(raw)
            if not math.isfinite(value) or abs(value) > 1e6:
                raise ValueError()
            values.append(value)
        except (ValueError, TypeError, KeyError, OverflowError):
            raise ValueError(f'{code} requires a finite number. Blank values and NaN/Inf are not allowed.') from None
    if values[0] <= 0 or values[1] <= 0:
        raise ValueError('Molar mass and the H/C atomic ratio must be greater than zero.')
    if not 0 <= values[2] <= 1:
        raise ValueError('Aromatic carbon fraction X03 must be between 0 and 1.')
    if any(v < 0 or not v.is_integer() for v in values[3:5]):
        raise ValueError('Ring count and branching carbon count must be nonnegative integers.')
    if values[5] < math.log(2) - 1e-12 or values[6] <= 0:
        raise ValueError('X06 = ln(1+n) must be at least ln(2); X07 must be greater than zero.')
    return values


class Predictor:
    def __init__(self, root):
        self.root = Path(root)
        self.manifest = json.loads((self.root / 'models/manifest.json').read_text(encoding='utf-8'))
        self.models = {}
        for target in TARGETS:
            p = self.root / f'models/{target}.json.gz'
            if target in self.manifest['models']:
                if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=self.manifest['models'][target]['sha256']:
                    raise ValueError(f'{target} model file is missing or failed its integrity check. Extract the complete application package again.')
                with gzip.open(p, 'rt', encoding='utf-8') as f:
                    self.models[target] = json.load(f)
        self.catalog = json.loads((self.root / 'data/catalog.json').read_text(encoding='utf-8'))
        self._background = self.manifest.get('explanation_background', [])
        self._standardized = [[(v-m)/s for v,m,s in zip(r['x'],self.manifest['distance']['mean'],self.manifest['distance']['scale'])]
                              for r in self.manifest['distance']['records']]

    def predict(self, row):
        x = validate(row)
        output = {t: predict_model(m, x) for t, m in self.models.items()}
        warnings = []
        missing=[t for t in TARGETS if t not in output]
        if missing:
            warnings.append('Models pending: '+', '.join(missing)+'. Only partial property results are available.')
        for i, c in enumerate(FEATURES):
            lo, hi = self.manifest['ranges'][c]
            if x[i] < lo - 1e-9 or x[i] > hi + 1e-9:
                warnings.append(f'{c} is outside the modeling data range [{lo:.5g}, {hi:.5g}]')
        d = self.manifest['distance']
        z = [(v-m)/s for v,m,s in zip(x,d['mean'],d['scale'])]
        distances = [math.sqrt(sum((a-b)**2 for a,b in zip(z,r))) for r in self._standardized]
        near = sorted(range(len(distances)), key=distances.__getitem__)[:3]
        distance = distances[near[0]]
        reference = d['reference_sorted']
        percentile = 100 * bisect.bisect_right(reference, distance) / len(reference)
        if percentile >= 95:
            warnings.append('Descriptor distance is in the highest 5% of the reference distribution, indicating substantial extrapolation.')
        if output.get('Y03', 1) <= 0 or output.get('Y07', 1) <= 0:
            warnings.append('Nonpositive density or viscosity predicted. Check the inputs before using these results for screening.')
        if output.get('Y04', -1000) >= output.get('Y05', 1000):
            warnings.append('The predicted transition temperature is not below the boiling point; the physical ordering is inconsistent.')
        return {'inputs': dict(zip(FEATURES,x)), 'outputs': output, 'warnings': warnings,
                'distance': distance, 'distance_percentile': percentile,
                'nearest': [{**d['records'][i], 'distance': distances[i]} for i in near],
                'version': self.manifest['version']}

    def explain(self, row, target, progress=None):
        """Exact 2**7-subset interventional Shapley over a fixed 12-record background."""
        x = validate(row)
        model = self.models[target]
        background = self._background
        values = []
        for mask in range(128):
            if mask == 127:
                value = predict_model(model, x)
            else:
                value = sum(predict_model(model, [x[j] if mask & (1 << j) else b[j] for j in range(7)])
                            for b in background) / len(background)
            values.append(value)
            if progress and mask % 8 == 0:
                progress(mask / 128)
        phi = []
        for j in range(7):
            p = 0.0
            for mask in range(128):
                if mask & (1 << j):
                    continue
                k = mask.bit_count()
                p += (values[mask | (1 << j)] - values[mask]) / (7 * math.comb(6,k))
            phi.append(p)
        return {'target': target, 'baseline': values[0], 'prediction': values[-1],
                'contributions': dict(zip(FEATURES,phi)), 'background_n': len(background),
                'additivity_error': values[-1] - values[0] - sum(phi)}


def read_batch(path):
    path = Path(path)
    if path.suffix.lower() == '.xlsx':
        from openpyxl import load_workbook
        w = load_workbook(path, read_only=True, data_only=True)
        try:
            s = w.active
            rows = iter(s.values)
            for i, headers in enumerate(rows):
                if all(c in headers for c in FEATURES) or 'SMILES' in headers or 'smiles' in headers:
                    break
                if i >= 10:
                    raise ValueError('X01–X07 or SMILES column headers were not found within the first 11 rows.')
            else:
                raise ValueError('The worksheet is empty or lacks the required input columns.')
            return list(itertools.islice((dict(zip(headers,r)) for r in rows if any(v is not None for v in r)),10001))
        finally:
            w.close()
    last_error = None
    for encoding in ('utf-8-sig','gb18030'):
        try:
            with path.open('r',encoding=encoding,newline='') as f:
                sample=f.read(4096);f.seek(0)
                delimiter='\t' if path.suffix.lower()=='.tsv' else ','
                return list(itertools.islice(csv.DictReader(f,delimiter=delimiter),10001))
        except UnicodeDecodeError as exc:
            last_error=exc
    raise ValueError(f'Unable to decode the CSV file: {last_error}')


def predict_batch(predictor, rows, progress=None):
    if len(rows) > 10000:
        raise ValueError('A batch can contain at most 10,000 records. Split the file into smaller batches.')
    out=[]
    for i,row in enumerate(rows):
        identity={k:row[k] for k in ('Name','name','record_id','SMILES','smiles') if k in row}
        if not (identity.get('Name') or identity.get('name')) and row.get('\u5206\u5b50'):
            identity['Name']=row['\u5206\u5b50']
        result={'row':i+1,**identity}
        try:
            features={k:row.get(k) for k in FEATURES}
            smiles=row.get('SMILES') or row.get('smiles') or row.get('Canonical SMILES')
            if any(features[k] is None or str(features[k]).strip()=='' for k in FEATURES):
                if not smiles:
                    raise ValueError('Provide all X01–X07 values or a SMILES string.')
                from .descriptors import from_smiles
                features,_=from_smiles(str(smiles))
            elif smiles:
                from .descriptors import from_smiles
                computed,_=from_smiles(str(smiles))
                numeric=validate(features)
                if any(abs(v-computed[c])>1e-6 for c,v in zip(FEATURES,numeric)):
                    raise ValueError('SMILES and X01–X07 do not match. Use one input method or recalculate the descriptors.')
            p=predictor.predict(features)
            result.update(features)
            result.update({f'{t}_pred':p['outputs'].get(t) for t in TARGETS})
            result.update(status='ok' if len(p['outputs'])==7 else 'partial', error='', warnings='; '.join(p['warnings']), distance_percentile=p['distance_percentile'],
                          model_version=p['version'],source_sha256=predictor.manifest['source_sha256'])
        except (ValueError, TypeError, ImportError) as exc:
            result.update(status='error',error=str(exc))
        out.append(result)
        if progress:
            progress((i+1)/max(1,len(rows)))
    return out


def write_csv(path, rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        writer.writeheader()
        # Escape text cells that spreadsheet software may interpret as formulas.
        for row in rows:
            safe={k:("'"+v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v) for k,v in row.items()}
            writer.writerow(safe)

"""Native Tk desktop front end. All computations and files stay on the device."""
import csv
import json
import os
import queue
import sys
import threading
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path
from tkinter import ttk,filedialog,messagebox
from .schema import FEATURES,TARGETS,INPUTS,OUTPUTS
from .engine import Predictor,read_batch,predict_batch,write_csv

BG='#F2F5F8';INK='#152A3B';MUTED='#667B8B';TEAL='#097E81';NAVY='#132A3A';LINE='#DDE5EA'


class App(tk.Tk):
    def __init__(self,root):
        super().__init__()
        self.title('SAF-Predict 300 · Molecular Property Predictor')
        self.geometry('1360x880');self.minsize(1240,830);self.configure(bg=BG)
        self.root_path=Path(root);self.predictor=Predictor(root)
        self.events=queue.Queue();self.busy=False;self.buttons=[];self.pages={};self.nav={}
        self.current_result=None;self.batch_results=[];self.epoch=0;self.descriptor_origin=None
        families=tkfont.families(self)
        self.font='Segoe UI' if 'Segoe UI' in families else ('Helvetica Neue' if 'Helvetica Neue' in families else 'Arial')
        self.option_add('*Font',(self.font,10))
        self.option_add('*TCombobox*Listbox.font',(self.font,10))
        style=ttk.Style(self);style.theme_use('clam')
        style.configure('.',font=(self.font,10),background=BG,foreground=INK)
        style.configure('TButton',padding=(12,8),background='#FFFFFF',bordercolor=LINE,focuscolor=TEAL)
        style.map('TButton',background=[('active','#E5F0F1')])
        style.configure('Accent.TButton',background=TEAL,foreground='white',bordercolor=TEAL)
        style.map('Accent.TButton',background=[('active','#096567'),('disabled','#91B5B7')],foreground=[('disabled','white')])
        style.configure('TEntry',fieldbackground='white',padding=7,bordercolor=LINE)
        style.configure('TCombobox',fieldbackground='white',padding=6)
        style.configure('Treeview',background='white',fieldbackground='white',rowheight=32,borderwidth=0)
        style.configure('Treeview.Heading',background='#E9EFF3',font=(self.font,10,'bold'),padding=8)
        style.map('Treeview',background=[('selected','#D8EEEE')],foreground=[('selected',INK)])
        self._layout();self._menus();self.after(70,self._poll)
        self.protocol('WM_DELETE_WINDOW',self.destroy)
        self.show_page('single')

    def label(self,parent,text,size=10,bold=False,color=INK,**kw):
        return tk.Label(parent,text=text,font=(self.font,size,'bold' if bold else 'normal'),
                        fg=color,bg=parent.cget('bg'),anchor='w',**kw)

    def button(self,parent,text,command,accent=False,job=False):
        b=ttk.Button(parent,text=text,command=command,style='Accent.TButton' if accent else 'TButton')
        if job:self.buttons.append(b)
        return b

    def card(self,parent,**kw):
        return tk.Frame(parent,bg='white',highlightbackground=LINE,highlightthickness=1,**kw)

    def _layout(self):
        self.columnconfigure(1,weight=1);self.rowconfigure(0,weight=1)
        side=tk.Frame(self,bg=NAVY,width=210);side.grid(row=0,column=0,sticky='nsew');side.grid_propagate(False)
        logo=tk.Canvas(side,width=140,height=64,bg=NAVY,highlightthickness=0);logo.pack(anchor='w',padx=23,pady=(30,8))
        points=[(12,38),(34,24),(57,38),(79,24),(101,38)]
        for a,b in zip(points,points[1:]):logo.create_line(*a,*b,fill='#69D5C9',width=3)
        for x,y in points:logo.create_oval(x-5,y-5,x+5,y+5,fill='#69D5C9',outline=NAVY)
        self.label(side,'SAF-Predict',19,True,'white').pack(anchor='w',padx=23)
        self.label(side,'MOLECULAR PROPERTY LAB',8,color='#8CA8B7').pack(anchor='w',padx=23,pady=(5,30))
        for key,text in [('single','Single Prediction'),('batch','Batch Prediction'),('library','Molecule Library'),('metrics','Models & Validation')]:
            b=tk.Label(side,text=text,anchor='w',padx=25,pady=13,
                        bg=NAVY,fg='#BDD0DB',relief='flat',bd=0,
                        font=(self.font,11),cursor='hand2',highlightthickness=0)
            b.bind('<Button-1>',lambda e,k=key:self.show_page(k))
            b.pack(fill='x',padx=10,pady=3);self.nav[key]=b
        foot=tk.Frame(side,bg=NAVY);foot.pack(side='bottom',fill='x',padx=23,pady=25)
        self.label(foot,'300  modeling molecules',11,True,'#EEF7FA').pack(anchor='w',pady=3)
        self.label(foot,'8  validation molecules',10,color='#BDD0DB').pack(anchor='w',pady=3)
        self.label(foot,f"v{self.predictor.manifest['version']}   /   Offline desktop",8,color='#8CA8B7').pack(anchor='w',pady=(18,0))
        main=tk.Frame(self,bg=BG);main.grid(row=0,column=1,sticky='nsew');main.rowconfigure(1,weight=1);main.columnconfigure(0,weight=1)
        header=tk.Frame(main,bg=BG);header.grid(row=0,column=0,sticky='ew',padx=26,pady=(23,14))
        self.heading=self.label(header,'',23,True);self.heading.pack(anchor='w')
        self.subtitle=self.label(header,'',10,color=MUTED);self.subtitle.pack(anchor='w',pady=(7,0))
        self.content=tk.Frame(main,bg=BG);self.content.grid(row=1,column=0,sticky='nsew',padx=26)
        self.content.rowconfigure(0,weight=1);self.content.columnconfigure(0,weight=1)
        status=tk.Frame(main,bg=BG);status.grid(row=2,column=0,sticky='ew',padx=26,pady=12)
        self.status=tk.StringVar(value='Ready. Enter descriptors or load a molecule.')
        self.label(status,'Hydrocarbon screening · Research use',9,color=MUTED).pack(side='right')
        self.status_label=self.label(status,'',9,color=MUTED);self.status_label.configure(textvariable=self.status);self.status_label.pack(side='left')
        self.progress=ttk.Progressbar(status,length=100,mode='determinate');self.progress.pack(side='left',padx=12)
        for key in ('single','batch','library','metrics'):
            p=tk.Frame(self.content,bg=BG);p.grid(row=0,column=0,sticky='nsew');self.pages[key]=p
        self._single();self._batch();self._library();self._metrics()

    def _menus(self):
        menu=tk.Menu(self);file=tk.Menu(menu,tearoff=False);run=tk.Menu(menu,tearoff=False);view=tk.Menu(menu,tearoff=False)
        file.add_command(label='Load example molecule',command=self.demo,accelerator='Ctrl+D')
        file.add_command(label='Import batch file',command=self.import_batch,accelerator='Ctrl+O')
        file.add_command(label='Export current prediction',command=self.export_single,accelerator='Ctrl+S')
        file.add_separator();file.add_command(label='Exit',command=self.destroy)
        run.add_command(label='Predict properties',command=self.on_predict,accelerator='Ctrl+Return')
        run.add_command(label='Calculate from SMILES',command=self.calculate_smiles)
        run.add_command(label='View local contributions',command=self.on_explain,accelerator='Ctrl+E')
        for key,title in [('single','Single Prediction'),('batch','Batch Prediction'),('library','Molecule Library'),('metrics','Models & Validation')]:
            view.add_command(label=title,command=lambda k=key:self.show_page(k))
        menu.add_cascade(label='File',menu=file);menu.add_cascade(label='Calculate',menu=run);menu.add_cascade(label='View',menu=view)
        examples=tk.Menu(menu,tearoff=False)
        for key,record in zip('jklmnprt',[r for r in self.predictor.catalog if r['role']=='validation']):
            examples.add_command(label=f"{record['validation_id']}  {record['name']}",command=lambda r=record:self.set_row(r),accelerator=f'Ctrl+{key.upper()}')
            self.bind(f'<Control-Key-{key}>',lambda e,r=record:self.set_row(r))
            if sys.platform=='darwin':self.bind(f'<Command-Key-{key}>',lambda e,r=record:self.set_row(r))
        menu.add_cascade(label='Validation Examples',menu=examples)
        self.config(menu=menu)
        for key,fn in [('d',self.demo),('e',self.on_explain),('o',self.import_batch),('s',self.export_single),('Return',self.on_predict),
                       ('1',lambda:self.show_page('single')),('2',lambda:self.show_page('batch')),('3',lambda:self.show_page('library')),('4',lambda:self.show_page('metrics'))]:
            self.bind(f'<Control-Key-{key}>',lambda e,f=fn:f())
            if sys.platform=='darwin':self.bind(f'<Command-Key-{key}>',lambda e,f=fn:f())

    def show_page(self,key):
        titles={'single':('Molecular Property Prediction','7 structural descriptors  →  7 independent property targets'),
                'batch':('Batch Prediction','Import CSV or Excel, predict locally, and export results.'),
                'library':('Molecule Library','Reference values for 300 modeling molecules and 8 held-out validation molecules.'),
                'metrics':('Models & Validation','Cross-validation grouped by molecular formula · Separate property models · Traceable data')}
        self.heading.configure(text=titles[key][0]);self.subtitle.configure(text=titles[key][1]);self.pages[key].tkraise()
        for k,b in self.nav.items():b.configure(bg='#254958' if key==k else NAVY,fg='white' if key==k else '#BDD0DB')

    def _single(self):
        page=self.pages['single'];page.columnconfigure(1,weight=1);page.rowconfigure(0,weight=1)
        left=self.card(page,width=330);left.grid(row=0,column=0,sticky='nsew',padx=(0,16));left.grid_propagate(False)
        form=tk.Frame(left,bg='white');form.pack(fill='both',expand=True,padx=17,pady=16)
        self.label(form,'Molecule Input',13,True).pack(anchor='w')
        self.molecule_name=tk.StringVar(value='Unnamed molecule')
        ttk.Entry(form,textvariable=self.molecule_name).pack(fill='x',pady=(9,10))
        self.label(form,'SMILES (optional)',9,color=MUTED).pack(anchor='w')
        self.smiles=tk.StringVar()
        self.smiles.trace_add('write',self._invalidate)
        ttk.Entry(form,textvariable=self.smiles).pack(fill='x',pady=(4,6))
        self.button(form,'Calculate from SMILES',self.calculate_smiles,job=True).pack(fill='x',pady=(0,10))
        grid=tk.Frame(form,bg='white');grid.pack(fill='x')
        grid.columnconfigure(1,weight=1);self.inputs={}
        for i,c in enumerate(FEATURES):
            label=INPUTS[c][0]
            self.label(grid,f'{c}  {label}',9).grid(row=i,column=0,sticky='w',pady=4,padx=(0,8))
            v=tk.StringVar();e=ttk.Entry(grid,textvariable=v,width=11);e.grid(row=i,column=1,sticky='ew',pady=4)
            v.trace_add('write',self._invalidate);self.inputs[c]=v
        self.button(form,'Predict Properties',self.on_predict,True,True).pack(fill='x',pady=(14,7))
        actions=tk.Frame(form,bg='white');actions.pack(fill='x')
        self.button(actions,'Load Example',self.demo).pack(side='left',fill='x',expand=True,padx=(0,4))
        self.button(actions,'Export Results',self.export_single).pack(side='left',fill='x',expand=True,padx=(4,0))
        self.label(form,'X01: g/mol. X03: fraction (0–1).\nX06: ln(1+n) of graph automorphisms.',9,color=MUTED,justify='left').pack(anchor='w',pady=(15,0))
        right=tk.Frame(page,bg=BG);right.grid(row=0,column=1,sticky='nsew');right.columnconfigure(0,weight=1);right.rowconfigure(2,weight=1)
        self.result_title=self.label(right,'Prediction Results',13,True);self.result_title.grid(row=0,column=0,sticky='w',pady=(0,9))
        cards=tk.Frame(right,bg=BG);cards.grid(row=1,column=0,sticky='ew');cards.columnconfigure((0,1),weight=1)
        self.values={};self.model_labels={}
        for i,c in enumerate(TARGETS):
            p=self.card(cards);p.grid(row=i//2,column=i%2,sticky='ew',padx=(0,8) if i%2==0 else (0,0),pady=(0,8))
            inside=tk.Frame(p,bg='white');inside.pack(fill='both',padx=13,pady=10)
            self.label(inside,f'{c}   {OUTPUTS[c][0]}',10,True).pack(anchor='w')
            val=self.label(inside,'—',23,True,TEAL);val.pack(anchor='w',pady=(3,0));self.values[c]=val
            self.label(inside,f'{OUTPUTS[c][2]}    ·    {OUTPUTS[c][3]}',8,color=MUTED).pack(anchor='w')
        expl=self.card(cards);expl.grid(row=3,column=1,sticky='nsew',pady=(0,8))
        self.label(expl,'Local Feature Contributions',10,True).pack(anchor='w',padx=13,pady=(9,4))
        self.explain_target=tk.StringVar(value='Y01')
        box=ttk.Combobox(expl,textvariable=self.explain_target,values=TARGETS,state='readonly',width=9);box.pack(side='left',padx=(13,5),pady=(0,8))
        self.button(expl,'Explain',self.on_explain,job=True).pack(side='left',pady=(0,8))
        note=self.card(right);note.grid(row=2,column=0,sticky='nsew',pady=(4,0))
        self.info=tk.Text(note,height=6,wrap='word',relief='flat',bg='white',fg=MUTED,font=(self.font,10),padx=13,pady=10)
        self.info.pack(fill='both',expand=True)
        self.set_info('Enter a molecule, then click Predict Properties.\n\nY02 is predicted directly by its own SVR using X01–X07.\nTransition temperature refers to a pure component. Viscosity is evaluated at 40°C.')

    def _invalidate(self,*_):
        self.epoch+=1;self.current_result=None
        if hasattr(self,'values'):
            for v in self.values.values():v.configure(text='—')
            self.result_title.configure(text='Results · Awaiting prediction')

    def set_info(self,text):
        self.info.configure(state='normal');self.info.delete('1.0','end');self.info.insert('1.0',text);self.info.configure(state='disabled')

    def row(self):return {k:v.get() for k,v in self.inputs.items()}

    def set_row(self,row):
        self.molecule_name.set(row.get('name','Unnamed molecule'));self.smiles.set(row.get('smiles',''))
        for c in FEATURES:self.inputs[c].set(f'{float(row[c]):.14g}')
        self.descriptor_origin=(self.smiles.get(),self.row())
        self.show_page('single');self.status.set('Molecule loaded. Click Predict Properties to continue.')

    def demo(self):
        example=next((r for r in self.predictor.catalog if r['name'].lower()=='dodecane'),self.predictor.catalog[0])
        self.set_row(example)

    def calculate_smiles(self):
        smiles=self.smiles.get().strip()
        if not smiles:return messagebox.showinfo('SMILES Required','Enter a SMILES string first.',parent=self)
        def work(progress):
            from .descriptors import from_smiles
            return from_smiles(smiles)
        def done(result):
            if self.smiles.get().strip()!=smiles:
                self.status.set('SMILES changed. Recalculate the descriptors.');return
            features,identity=result
            for c,v in features.items():self.inputs[c].set(f'{v:.14g}')
            self.descriptor_origin=(self.smiles.get(),self.row())
            self.set_info(f"Formula: {identity['formula']}\nCanonical SMILES: {identity['smiles']}\n\nAll seven descriptors are ready. Click Predict Properties.")
        self.job('Calculating descriptors…',work,done)

    def on_predict(self):
        row=self.row();epoch=self.epoch;name=self.molecule_name.get();smiles=self.smiles.get()
        if smiles.strip() and self.descriptor_origin!=(smiles,row):
            return messagebox.showinfo('Check Structure Input','The SMILES string or descriptors have changed. Recalculate the descriptors from SMILES, or clear SMILES to use manually entered descriptors.',parent=self)
        def done(result):
            if self.epoch!=epoch:
                self.status.set('Inputs changed. Run the prediction again.');return
            self.current_result={**result,'name':name,'smiles':smiles}
            self.result_title.configure(text=f'Prediction Results · {name[:42]}')
            for c in TARGETS:
                value=result['outputs'].get(c)
                self.values[c].configure(text=f'{value:.{OUTPUTS[c][4]}f}' if value is not None else 'Pending')
            near=result['nearest'][0]
            lines=[f"Descriptor-distance percentile: P{result['distance_percentile']:.1f}",f"Nearest modeling molecule: {near['name']} ({near['record_id']})",
                   'The distance percentile describes structural proximity, not prediction confidence.']
            lines+=result['warnings']
            if 'Y04' in self.predictor.manifest['metrics']:
                mae=self.predictor.manifest['metrics']['Y04']['cv']['MAE']
                lines.append(f'Transition-temperature grouped CV MAE: {mae:.1f} °C. Low-temperature screening requires experimental verification.')
            self.set_info('\n'.join(lines))
        self.job('Predicting properties…',lambda p:self.predictor.predict(row),done)

    def export_single(self):
        if not self.current_result:return messagebox.showinfo('No Results','Run a prediction first.',parent=self)
        path=filedialog.asksaveasfilename(parent=self,title='Export Prediction',defaultextension='.csv',initialfile='SAF_prediction.csv',filetypes=[('CSV','*.csv'),('JSON','*.json')])
        if not path:return
        r=self.current_result
        try:
            if Path(path).suffix.lower()=='.json':Path(path).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
            else:write_csv(path,[{'name':r['name'],'smiles':r['smiles'],**r['inputs'],**{c+'_pred':r['outputs'].get(c) for c in TARGETS},
                                  'model_version':r['version'],'source_sha256':self.predictor.manifest['source_sha256'],
                                  'distance_percentile':r['distance_percentile'],'warnings':'; '.join(r['warnings'])}])
            self.status.set(f'Saved: {Path(path).name}')
        except OSError as exc:messagebox.showerror('Save Failed',str(exc),parent=self)

    def on_explain(self):
        if not self.current_result:return messagebox.showinfo('Prediction Required','Run a molecule prediction first.',parent=self)
        row=dict(self.current_result['inputs']);target=self.explain_target.get()
        if target not in self.predictor.models:return messagebox.showinfo('Model Not Ready',f'{target} has not been trained yet.',parent=self)
        self.job('Calculating Shapley contributions…',lambda p:self.predictor.explain(row,target,p),self.show_explanation)

    def show_explanation(self,r):
        win=tk.Toplevel(self);win.title(f"{r['target']} · Local Feature Contributions");win.geometry('760x580');win.configure(bg='white')
        self.label(win,f"{OUTPUTS[r['target']][0]} · Local Feature Contributions",17,True).pack(anchor='w',padx=24,pady=(22,8))
        self.label(win,f"Baseline {r['baseline']:.4g}  +  contributions  =  prediction {r['prediction']:.4g} {OUTPUTS[r['target']][2]}",11,color=MUTED).pack(anchor='w',padx=24)
        canvas=tk.Canvas(win,bg='white',height=350,highlightthickness=0);canvas.pack(fill='both',expand=True,padx=20,pady=15)
        pairs=sorted(r['contributions'].items(),key=lambda p:abs(p[1]),reverse=True)
        maxval=max(abs(v) for _,v in pairs) or 1
        for i,(c,v) in enumerate(pairs):
            y=25+i*43;length=v/maxval*140;x0=460
            canvas.create_text(5,y+9,text=f'{c}  {INPUTS[c][0]}',anchor='w',fill=INK,font=(self.font,11))
            canvas.create_rectangle(min(x0,x0+length),y,max(x0,x0+length),y+21,fill=TEAL if v>=0 else '#C07953',outline='')
            canvas.create_text(x0+length+(8 if v>=0 else -8),y+10,text=f'{v:+.4g}',anchor='w' if v>=0 else 'e',fill=INK,font=(self.font,10))
        canvas.create_line(460,12,460,326,fill=LINE)
        self.label(win,f"Exact enumeration of 128 subsets of 7 inputs; a fixed background of {r['background_n']} modeling molecules.\nContributions explain this model output, not causal effects or prediction error.",10,color=MUTED,justify='left').pack(anchor='w',padx=24,pady=(0,20))

    def table(self,parent,columns,widths=None):
        holder=tk.Frame(parent,bg='white');holder.pack(fill='both',expand=True)
        tree=ttk.Treeview(holder,columns=columns,show='headings',selectmode='browse')
        sy=ttk.Scrollbar(holder,orient='vertical',command=tree.yview);sx=ttk.Scrollbar(holder,orient='horizontal',command=tree.xview)
        tree.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        tree.grid(row=0,column=0,sticky='nsew');sy.grid(row=0,column=1,sticky='ns');sx.grid(row=1,column=0,sticky='ew')
        holder.rowconfigure(0,weight=1);holder.columnconfigure(0,weight=1)
        for i,c in enumerate(columns):tree.heading(c,text=c);tree.column(c,width=widths[i] if widths else 110,minwidth=75,anchor='w')
        return tree

    def _batch(self):
        page=self.pages['batch']
        toolbar=tk.Frame(page,bg=BG);toolbar.pack(fill='x',pady=(0,13))
        self.button(toolbar,'Import & Predict',self.import_batch,True,True).pack(side='left',padx=(0,8))
        self.button(toolbar,'Save Input Template',self.save_template).pack(side='left',padx=(0,8))
        self.button(toolbar,'Export All Results',self.export_batch).pack(side='left')
        self.batch_note=self.label(page,'Provide X01–X07 columns or a SMILES column. Results and errors are retained for each row.',10,color=MUTED)
        self.batch_note.pack(anchor='w',pady=(0,12))
        panel=self.card(page);panel.pack(fill='both',expand=True)
        self.batch_table=self.table(panel,['Row','Molecule','Status']+[f'{c} ({OUTPUTS[c][2]})' for c in TARGETS]+['Error / Warning'],[65,180,80]+[125]*7+[270])
        self.label(page,'Exports use UTF-8 CSV with a byte-order mark for Excel compatibility.',9,color=MUTED).pack(anchor='w',pady=12)

    def import_batch(self):
        path=filedialog.askopenfilename(parent=self,filetypes=[('Input files','*.csv *.tsv *.xlsx'),('CSV','*.csv'),('Excel','*.xlsx')])
        if not path:return
        def work(p):return predict_batch(self.predictor,read_batch(path),p)
        def done(rows):
            self.batch_results=rows;self.batch_table.delete(*self.batch_table.get_children())
            for r in rows[:1000]:
                name=r.get('Name') or r.get('name') or r.get('SMILES') or r.get('smiles') or ''
                self.batch_table.insert('','end',values=[r['row'],name,r['status']]+[f"{r[c+'_pred']:.5g}" if r.get(c+'_pred') is not None else '—' for c in TARGETS]+[r.get('error') or r.get('warnings','')])
            good=sum(r['status']=='ok' for r in rows)
            partial=sum(r['status']=='partial' for r in rows)
            self.batch_note.configure(text=f'{len(rows)} rows: {good} complete, {partial} partial, {len(rows)-good-partial} errors. '+('Showing the first 1,000 rows; exports include all rows.' if len(rows)>1000 else ''))
        self.job('Running batch predictions…',work,done)

    def save_template(self):
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',initialfile='SAF_input_template.csv',filetypes=[('CSV','*.csv')])
        if path:
            r=self.predictor.catalog[0]
            try:write_csv(path,[{'Name':r['name'],**{c:r[c] for c in FEATURES},'SMILES':r['smiles']}])
            except OSError as exc:messagebox.showerror('Save Failed',str(exc),parent=self)

    def export_batch(self):
        if not self.batch_results:return messagebox.showinfo('No Results','Import a file and run predictions first.',parent=self)
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.csv',initialfile='SAF_batch_predictions.csv',filetypes=[('CSV','*.csv')])
        if path:
            try:write_csv(path,self.batch_results);self.status.set('Batch results saved.')
            except OSError as exc:messagebox.showerror('Save Failed',str(exc),parent=self)

    def _library(self):
        page=self.pages['library'];bar=tk.Frame(page,bg=BG);bar.pack(fill='x',pady=(0,12))
        self.query=tk.StringVar();ttk.Entry(bar,textvariable=self.query,width=32).pack(side='left',padx=(0,8))
        self.query.trace_add('write',lambda *_:self.filter_library())
        self.partition=tk.StringVar(value='All molecules')
        sel=ttk.Combobox(bar,textvariable=self.partition,values=['All molecules','Modeling (300)','Validation (8)'],state='readonly',width=18);sel.pack(side='left',padx=(0,8));sel.bind('<<ComboboxSelected>>',lambda e:self.filter_library())
        self.button(bar,'Load Selected Molecule',self.load_selected).pack(side='left')
        self.library_count=self.label(page,'',9,color=MUTED);self.library_count.pack(anchor='w',pady=(0,9))
        panel=self.card(page);panel.pack(fill='both',expand=True)
        self.library_table=self.table(panel,['Record ID','Molecule','Formula','Role']+[f'{c} ({OUTPUTS[c][2]})' for c in TARGETS],[100,260,95,80]+[125]*7)
        self.library_table.bind('<Double-1>',lambda e:self.load_selected())
        self.library_table.bind('<<TreeviewSelect>>',self.library_details)
        self.library_detail=self.label(page,'Search by name, CAS, formula, or record ID. Double-click a molecule to load its inputs.',9,color=MUTED,wraplength=870,justify='left')
        self.library_detail.pack(anchor='w',pady=12)
        self.filter_library()

    def filter_library(self):
        if not hasattr(self,'library_table'):return
        q=self.query.get().strip().casefold();part=self.partition.get()
        self.library_table.delete(*self.library_table.get_children())
        count=0
        for r in self.predictor.catalog:
            if part.startswith('Modeling') and r['role']!='development':continue
            if part.startswith('Validation') and r['role']!='validation':continue
            if q and q not in ' '.join(str(r.get(k,'')) for k in ('name','cas','formula','record_id','smiles')).casefold():continue
            self.library_table.insert('','end',iid=r['record_id'],values=[r['record_id'],r['name'],r['formula'],'Modeling' if r['role']=='development' else r['validation_id']]+[f'{r[c]:.6g}' for c in TARGETS]);count+=1
        self.library_count.configure(text=f'Showing {count} molecules. Original T02 and T08 are excluded. Values are dataset references.')

    def selected_record(self):
        sel=self.library_table.selection()
        return next((r for r in self.predictor.catalog if sel and r['record_id']==sel[0]),None)

    def library_details(self,event=None):
        r=self.selected_record()
        if r:self.library_detail.configure(text=f"{r['name']}  |  CAS: {r['cas'] or 'not provided'}\nSMILES: {r['smiles']}\nReference IDs: {r['references']}")

    def load_selected(self):
        r=self.selected_record()
        if r:self.set_row(r)

    def _metrics(self):
        page=self.pages['metrics'];m=self.predictor.manifest
        summary=self.card(page);summary.pack(fill='x',pady=(0,14))
        self.label(summary,'300 modeling molecules   /   73 formula groups   /   8 held-out molecules',13,True).pack(anchor='w',padx=16,pady=(14,7))
        self.label(summary,'5 outer CV folds, 3 inner tuning folds; final models fitted on all 300 modeling molecules.',10,color=MUTED).pack(anchor='w',padx=16,pady=(0,14))
        panel=self.card(page);panel.pack(fill='both',expand=True)
        cols=['Property / Unit','Model','CV R²','CV MAE','CV RMSE','Holdout R²','Holdout MAE','Holdout RMSE']
        self.metrics_table=self.table(panel,cols,[330,90]+[105]*6)
        for c in TARGETS:
            scores=m['metrics'].get(c)
            vals=[f'{c} {OUTPUTS[c][0]} ({OUTPUTS[c][2]})',OUTPUTS[c][3]]
            vals+=([f"{scores[part][metric]:.4g}" for part in ('cv','validation') for metric in ('R2','MAE','RMSE')] if scores else ['Pending']*6)
            self.metrics_table.insert('','end',values=vals)
        text=('CV uses nested groups within fixed model families. Holdout data are excluded from fitting, tuning, and selection.\n'
              'Seven of the eight holdout formulas occur in the modeling set; this is an internal holdout evaluation.\n'
              'Reference values have mixed sources. R², MAE, and RMSE do not guarantee accuracy for a new molecule.\n'
              'Y02 uses a separate SVR target. Local contributions explain the deployed model.')
        self.label(page,text,10,color=MUTED,justify='left').pack(anchor='w',pady=(14,8))
        self.label(page,f"Dataset SHA-256: {m['source_sha256'][:32]}…",8,color=MUTED).pack(anchor='w')

    def job(self,text,work,done):
        if self.busy:return
        self.busy=True;self.status.set(text);self.progress['value']=0
        for b in self.buttons:b.state(['disabled'])
        def worker():
            try:
                result=work(lambda v:self.events.put(('progress',v,None)))
                self.events.put(('done',result,done))
            except Exception as exc:
                self.events.put(('error',str(exc),None))
        threading.Thread(target=worker,daemon=True).start()

    def _poll(self):
        try:
            while True:
                kind,data,callback=self.events.get_nowait()
                if kind=='progress':self.progress['value']=100*data
                else:
                    self.busy=False
                    for b in self.buttons:b.state(['!disabled'])
                    self.progress['value']=100 if kind=='done' else 0
                    if kind=='error':self.status.set('Calculation did not complete.');messagebox.showerror('Processing Failed',data,parent=self)
                    else:
                        self.status.set('Calculation complete.')
                        try:callback(data)
                        except Exception as exc:messagebox.showerror('Display Failed',str(exc),parent=self)
        except queue.Empty:pass
        self.after(70,self._poll)


def main(root=None):
    if sys.platform=='win32':
        import ctypes
        try:ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError,OSError):pass
    root=Path(root) if root else Path(__file__).resolve().parents[2]
    App(root).mainloop()

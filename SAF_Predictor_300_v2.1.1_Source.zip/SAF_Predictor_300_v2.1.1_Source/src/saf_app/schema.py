"""English display labels, scientific names, units, and model families."""
FEATURES = [f'X{i:02}' for i in range(1, 8)]
TARGETS = [f'Y{i:02}' for i in range(1, 8)]
INPUTS = {
    'X01': ('Molar mass', 'Molar mass', 'g/mol'),
    'X02': ('H/C ratio', 'H/C atomic ratio', '—'),
    'X03': ('Aromatic C fraction', 'Aromatic carbon fraction', '0–1'),
    'X04': ('Ring count', 'Ring count', 'count'),
    'X05': ('Branching C count', 'Branching carbon count', 'count'),
    'X06': ('Graph symmetry', 'Log graph automorphisms, ln(1+n)', '—'),
    'X07': ('Kier κ₂', 'Kier kappa2', '—'),
}
OUTPUTS = {
    'Y01': ('Mass-based NHOC', 'Mass-based net heat of combustion', 'MJ/kg', 'RF', 3),
    'Y02': ('Volumetric NHOC', 'Volumetric net heat of combustion', 'MJ/L', 'SVR', 3),
    'Y03': ('Density', 'Density', 'g/cm³', 'SVR', 4),
    'Y04': ('Solid–liquid transition', 'Solid–liquid transition temperature', '°C', 'XGBoost', 2),
    'Y05': ('Boiling point', 'Boiling point', '°C', 'SVR', 2),
    'Y06': ('Flash point', 'Flash point', '°C', 'SVR', 2),
    'Y07': ('Kinematic viscosity @40°C', 'Kinematic viscosity at 40°C', 'mm²/s', 'SVR', 4),
}

"""Behavioral checks: data isolation, numerical parity, failures, and explanations."""
import csv
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path
import joblib
import numpy as np

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from saf_app.engine import Predictor,predict_model,predict_batch,read_batch,write_csv,validate
from saf_app.descriptors import from_smiles
from saf_app.schema import FEATURES


class AppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.predictor=Predictor(ROOT)

    def test_holdout_exclusions_and_identity(self):
        train=[r for r in self.predictor.catalog if r['role']=='development']
        hold=[r for r in self.predictor.catalog if r['role']=='validation']
        self.assertEqual((len(train),len(hold)),(300,8))
        self.assertFalse({'HC-0002','HC-0103'} & {r['record_id'] for r in self.predictor.catalog})
        self.assertFalse({r['connectivity'] for r in train}&{r['connectivity'] for r in hold})
        with (ROOT/'data/cv_folds.csv').open(encoding='utf-8-sig') as f:
            folds=list(csv.DictReader(f))
        mapping={}
        for r in folds:
            mapping.setdefault(r['formula'],set()).add(r['outer_fold'])
        self.assertEqual(len(mapping),73)
        self.assertTrue(all(len(v)==1 for v in mapping.values()))

    def test_all_descriptor_definitions(self):
        for r in self.predictor.catalog:
            actual,_=from_smiles(r['smiles'])
            self.assertTrue(all(abs(r[c]-actual[c])<1e-9 for c in FEATURES),r['record_id'])

    def test_invalid_molecules(self):
        for smi in ('CCO','CC.CC','not-a-smiles','[CH3]','[13CH4]',''):
            with self.assertRaises(ValueError):from_smiles(smi)

    def test_invalid_inputs(self):
        base={c:self.predictor.catalog[0][c] for c in FEATURES}
        for c,value in [('X01',0),('X02',-1),('X03',1.1),('X04',1.5),('X05',-2),('X06',0),('X07',0),('X01','nan'),('X01','inf'),('X01',''),('X01',True)]:
            with self.assertRaises(ValueError,msg=f'{c}:{value}'):validate({**base,c:value})

    def test_portable_models_against_training_estimators(self):
        X=np.array([[r[c] for c in FEATURES] for r in self.predictor.catalog])
        for target,model in self.predictor.models.items():
            trained=joblib.load(ROOT/f'training/{target}.joblib')
            expected=trained.predict(X)
            actual=np.array([predict_model(model,row.tolist()) for row in X])
            self.assertLess(float(np.max(abs(expected-actual))),3e-4 if target=='Y04' else 1e-8,target)

    def test_y02_uses_its_own_model(self):
        self.assertIn('Y02',self.predictor.models)
        self.assertEqual(self.predictor.models['Y02']['kind'],'svr')
        actual=self.predictor.predict(self.predictor.catalog[0])['outputs']['Y02']
        other_models={t:self.predictor.models.pop(t) for t in ('Y01','Y03')}
        try:
            self.assertEqual(self.predictor.predict(self.predictor.catalog[0])['outputs']['Y02'],actual)
        finally:
            self.predictor.models.update(other_models)
        # A deliberately different Y02 model exposes accidental product derivation.
        original=self.predictor.models.get('Y02')
        constant={'kind':'svr','x_mean':[0]*7,'x_scale':[1]*7,'y_mean':0,'y_scale':1,
                  'intercept':123.,'gamma':.1,'dual_coef':[],'support_vectors':[]}
        try:
            self.predictor.models['Y02']=constant
            p=self.predictor.predict(self.predictor.catalog[0])
            self.assertEqual(p['outputs']['Y02'],123.)
            self.assertNotAlmostEqual(p['outputs']['Y02'],p['outputs']['Y01']*p['outputs']['Y03'])
        finally:
            if original is None:del self.predictor.models['Y02']
            else:self.predictor.models['Y02']=original

    def test_all_seven_evaluations_match_saved_predictions(self):
        targets={f'Y{i:02}' for i in range(1,8)}
        self.assertEqual(set(self.predictor.models),targets)
        self.assertEqual(set(self.predictor.manifest['metrics']),targets)
        with (ROOT/'data/cv_folds.csv').open(encoding='utf-8-sig') as f:
            folds={r['record_id']:int(r['outer_fold']) for r in csv.DictReader(f)}
        for target in targets:
            for split,suffix,role,count in [('cv','oof','development',300),('validation','validation','validation',8)]:
                with (ROOT/f'reports/{target}_{suffix}.csv').open(encoding='utf-8-sig') as f:
                    rows=list(csv.DictReader(f))
                expected={r['record_id']:r for r in self.predictor.catalog if r['role']==role}
                self.assertEqual(len(rows),count)
                self.assertEqual({r['record_id'] for r in rows},set(expected))
                for r in rows:
                    self.assertAlmostEqual(float(r['reference']),expected[r['record_id']][target])
                    if split=='cv':self.assertEqual(int(r['fold']),folds[r['record_id']])
                y=np.array([float(r['reference']) for r in rows]);p=np.array([float(r['prediction']) for r in rows])
                calculated={'n':count,'R2':1-np.sum((y-p)**2)/np.sum((y-y.mean())**2),
                            'MAE':np.mean(abs(y-p)),'RMSE':np.sqrt(np.mean((y-p)**2))}
                for key,value in calculated.items():
                    self.assertAlmostEqual(self.predictor.manifest['metrics'][target][split][key],value,places=10)

    def test_batch_keeps_errors_and_unicode(self):
        row={c:self.predictor.catalog[0][c] for c in FEATURES}
        result=predict_batch(self.predictor,[{'Name':'测试分子',**row},{'Name':'bad',**row,'X04':2.2},{'Name':'正癸烷','SMILES':'CCCCCCCCCC'}])
        self.assertEqual(len(result),3);self.assertEqual(result[1]['status'],'error')
        self.assertIn('integers',result[1]['error']);self.assertIn('Y05_pred',result[0]);self.assertIn('Y05_pred',result[2])
        with tempfile.TemporaryDirectory(prefix='中文路径_') as tmp:
            p=Path(tmp)/'批量结果.csv';write_csv(p,result);again=read_batch(p)
            self.assertEqual(again[0]['Name'],'测试分子');self.assertEqual(again[1]['status'],'error')

    def test_smiles_descriptor_mismatch_is_not_silently_exported(self):
        row={c:self.predictor.catalog[0][c] for c in FEATURES}
        result=predict_batch(self.predictor,[{**row,'SMILES':'CCCCCCCCCC'}])
        self.assertEqual(result[0]['status'],'error')
        self.assertIn('do not match',result[0]['error'])

    def test_explanations_are_additive_for_deployed_models(self):
        row=self.predictor.catalog[0]
        for target in self.predictor.models:
            result=self.predictor.explain(row,target)
            self.assertLess(abs(result['additivity_error']),1e-8,target)
            expected=predict_model(self.predictor.models[target],[row[c] for c in FEATURES])
            self.assertAlmostEqual(result['prediction'],expected,places=8)


if __name__=='__main__':unittest.main(verbosity=2)

"""Import the explicitly supplied workbook without modifying it."""
import csv
import hashlib
import json
import shutil
import sys
from pathlib import Path
import numpy as np
from openpyxl import load_workbook
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from saf_app.descriptors import from_smiles
from saf_app.schema import FEATURES,TARGETS

SOURCE=ROOT/'data/source_dataset.xlsx'


def write_json(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def write_csv(path, rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def prepare(source=SOURCE):
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()
    policy_path=ROOT/'data/training_policy.json'
    policy=json.loads(policy_path.read_text(encoding='utf-8')) if policy_path.exists() else {}
    approved=(policy.get('source_sha256')==source_sha256 and policy.get('Y02_use_cached_reference_values') is True)
    y02_status='formula_derived_user_approved' if approved else 'awaiting_user_clarification'
    w=load_workbook(source,read_only=True,data_only=True)
    wf=load_workbook(source,read_only=True,data_only=False)
    train=[];held=[];excluded=[];catalog=[];descriptor_audit=[]
    keys=['record_id','name','cas','pubchem_cid','formula','inchikey','smiles','source_partition']+FEATURES+TARGETS+['references']
    for sn,n in [('Sheet1',300),('Sheet2',10)]:
        rows=list(w[sn].iter_rows(min_row=5,values_only=True))
        rows=[r for r in rows if r[0]]
        assert len(rows)==n,(sn,len(rows))
        for i,r in enumerate(rows,1):
            record=dict(zip(keys,r))
            for col in FEATURES+TARGETS:
                if record[col] is None or not np.isfinite(float(record[col])):
                    raise ValueError(f'{sn}:{record["record_id"]}:{col} missing/nonfinite')
                record[col]=float(record[col])
            recomputed,identity=from_smiles(record['smiles'])
            differences={c:recomputed[c]-record[c] for c in FEATURES}
            if any(abs(d)>1e-9 for d in differences.values()):
                raise ValueError(f'Descriptor mismatch {record["record_id"]}: {differences}')
            descriptor_audit.append({'record_id':record['record_id'],**differences})
            record['connectivity']=identity['inchikey'].split('-')[0]
            record['original_test_id']=f'T{i:02}' if sn=='Sheet2' else ''
            record['validation_id']=''
            if sn=='Sheet1':
                record['role']='development';train.append(record)
            elif i in (2,8):
                record['role']='excluded_by_user';excluded.append(record)
            else:
                record['role']='validation';record['validation_id']=f'T{len(held)+1:02}';held.append(record)
            if record['role']!='excluded_by_user':catalog.append(record)
    assert len(train)==300 and len(held)==8 and len(excluded)==2
    assert len({r['record_id'] for r in train+held+excluded})==310
    X=np.array([[r[c] for c in FEATURES] for r in train])
    groups=np.array([r['formula'] for r in train])
    scaler=StandardScaler().fit(X);Z=scaler.transform(X)
    ref=[]
    for i,z in enumerate(Z):
        ref.append(float(np.linalg.norm(Z[groups!=groups[i]]-z,axis=1).min()))
    splits=list(GroupKFold(5).split(X,groups=groups))
    fold={int(i):k+1 for k,(_,test) in enumerate(splits) for i in test}
    write_csv(ROOT/'data/development.csv',train)
    write_csv(ROOT/'data/validation.csv',held)
    write_csv(ROOT/'data/excluded.csv',excluded)
    write_csv(ROOT/'reports/descriptor_audit.csv',descriptor_audit)
    write_csv(ROOT/'data/cv_folds.csv',[{'record_id':r['record_id'],'formula':r['formula'],'outer_fold':fold[i]} for i,r in enumerate(train)])
    write_json(ROOT/'data/catalog.json',catalog)
    overlaps=[]
    for r in held:
        overlaps.append({'validation_id':r['validation_id'],'original_test_id':r['original_test_id'],'record_id':r['record_id'],
                         'connectivity_matches':[t['record_id'] for t in train if t['connectivity']==r['connectivity']],
                         'descriptor_matches':[t['record_id'] for t in train if max(abs(t[c]-r[c]) for c in FEATURES)<1e-9],
                         'formula_seen':r['formula'] in set(groups)})
    y2_formulas={sn:sum(isinstance(c[0],str) and c[0].startswith('=') for c in wf[sn].iter_rows(min_row=5,min_col=17,max_col=17,values_only=True)) for sn in ['Sheet1','Sheet2']}
    audit={'source_filename':source.name,'source_sha256':source_sha256,
           'development_n':300,'validation_n':8,'excluded_n':2,'formula_groups':len(set(groups)),
           'exclusions':[{k:r[k] for k in ['record_id','name','original_test_id']} for r in excluded],
           'descriptor_recalculation_max_abs_error':max(abs(r[c]) for r in descriptor_audit for c in FEATURES),
           'Y02_formula_cells':y2_formulas,'Y02_source_status':y02_status,
           'Y02_prediction_method':'independent SVR; never Y01 prediction times Y03 prediction',
           'validation_overlap_audit':overlaps,
           'source_note':'Reference values include measured, database, derived and estimated values. Not an all-experimental dataset.'}
    write_json(ROOT/'reports/data_audit.json',audit)
    definitions=list(w['Sheet3'].values)
    write_json(ROOT/'data/definitions_and_references.json',definitions)
    if source.resolve()!=(ROOT/'data/source_dataset.xlsx').resolve():
        shutil.copy2(source,ROOT/'data/source_dataset.xlsx')
    manifest={'version':'2.1.1','source_sha256':audit['source_sha256'],'development_n':300,'validation_n':8,
              'formula_groups':len(set(groups)),'fit_n':300,'models':{},'metrics':{},
              'Y02_source_status':y02_status,
              'validation_description':'Eight user-designated internal holdout molecules; excluded from fitting and tuning.',
              'ranges':{c:[float(X[:,i].min()),float(X[:,i].max())] for i,c in enumerate(FEATURES)},
              'distance':{'mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist(),'reference_sorted':sorted(ref),
                          'definition':'Euclidean distance in standardized descriptor space; reference excludes the query formula group.',
                          'records':[{'record_id':r['record_id'],'name':r['name'],'formula':r['formula'],'x':X[i].tolist()} for i,r in enumerate(train)]},
              'explanation_background':X[np.random.default_rng(20260907).choice(len(X),12,replace=False)].tolist()}
    write_json(ROOT/'models/manifest.json',manifest)
    print(json.dumps(audit,ensure_ascii=False,indent=2))


if __name__=='__main__':
    prepare(Path(sys.argv[1]) if len(sys.argv)>1 else SOURCE)

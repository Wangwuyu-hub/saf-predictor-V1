"""Fixed-family nested formula-group CV, final 300-record fit, independent export.

Each response, including Y02, has its own estimator. Preprocessing is fitted
inside each CV training fold. Validation labels never enter tuning or fitting.
"""
import argparse
import csv
import gzip
import hashlib
import json
import sys
from datetime import datetime,timezone
from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.compose import TransformedTargetRegressor
from sklearn.model_selection import GridSearchCV,GroupKFold
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
from xgboost import XGBRegressor

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from saf_app.schema import FEATURES,TARGETS,OUTPUTS
from saf_app.engine import predict_model


def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def write_csv(path,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def metrics(y,p):
    return {'n':len(y),'R2':float(r2_score(y,p)),'MAE':float(mean_absolute_error(y,p)),
            'RMSE':float(np.sqrt(mean_squared_error(y,p)))}


def estimator(target,seed):
    family=OUTPUTS[target][3]
    if family=='RF':
        return RandomForestRegressor(n_estimators=500,n_jobs=1,random_state=seed), {
            'max_depth':[None,8],'min_samples_leaf':[1,3],'max_features':['sqrt',1.0]}
    if family=='XGBoost':
        return XGBRegressor(objective='reg:squarederror',tree_method='hist',colsample_bytree=.8,
                            reg_lambda=1.,n_jobs=1,random_state=seed,verbosity=0), [
            {'learning_rate':[lr],'n_estimators':[n],'max_depth':[2,3],'min_child_weight':[1,5],'subsample':[.85]}
            for lr,n in [(.03,500),(.1,200)]]
    return TransformedTargetRegressor(regressor=Pipeline([('scale',StandardScaler()),('svr',SVR())]),transformer=StandardScaler()), {
        'regressor__svr__C':[1.,10.,100.],'regressor__svr__gamma':['scale',.1],'regressor__svr__epsilon':[.05,.1]}


def search_fit(target,X,y,groups,seed,jobs):
    model,grid=estimator(target,seed)
    search=GridSearchCV(model,grid,cv=GroupKFold(3),scoring='neg_root_mean_squared_error',n_jobs=jobs,error_score='raise')
    search.fit(X,y,groups=groups)
    return search.best_estimator_,search.best_params_


def export_model(m,family):
    if family=='RF':
        return {'kind':'rf','trees':[{'left':t.tree_.children_left.tolist(),'right':t.tree_.children_right.tolist(),
                                     'feature':t.tree_.feature.tolist(),'threshold':t.tree_.threshold.tolist(),
                                     'value':t.tree_.value[:,0,0].tolist()} for t in m.estimators_]}
    if family=='SVR':
        sc=m.regressor_.named_steps['scale'];sv=m.regressor_.named_steps['svr']
        return {'kind':'svr','x_mean':sc.mean_.tolist(),'x_scale':sc.scale_.tolist(),
                'y_mean':float(m.transformer_.mean_[0]),'y_scale':float(m.transformer_.scale_[0]),
                'gamma':float(sv._gamma),'intercept':float(sv.intercept_[0]),
                'dual_coef':sv.dual_coef_[0].tolist(),'support_vectors':sv.support_vectors_.tolist()}
    obj=json.loads(m.get_booster().save_raw(raw_format='json'))['learner']
    base=obj['learner_model_param']['base_score']
    return {'kind':'xgb','base_score':float(base.strip('[]')),
            'trees':[{'left':t['left_children'],'right':t['right_children'],'feature':t['split_indices'],
                      'threshold':t['split_conditions']} for t in obj['gradient_booster']['model']['trees']]}


def run(targets,jobs):
    train=read_csv(ROOT/'data/development.csv');holdout=read_csv(ROOT/'data/validation.csv')
    X=np.array([[float(r[c]) for c in FEATURES] for r in train]);groups=np.array([r['formula'] for r in train])
    Xh=np.array([[float(r[c]) for c in FEATURES] for r in holdout])
    folds=list(GroupKFold(5).split(X,groups=groups))
    assert len(train)==300 and len(holdout)==8
    for target in targets:
        manifest=json.loads((ROOT/'models/manifest.json').read_text(encoding='utf-8'))
        if target=='Y02' and manifest['Y02_source_status']=='awaiting_user_clarification':
            raise RuntimeError('Y02 reference values require resolution before training.')
        y=np.array([float(r[target]) for r in train]);oof=np.full(len(y),np.nan);fold_rows=[];params=[]
        print(f'{target}: nested grouped CV on 300 records',flush=True)
        for k,(tr,te) in enumerate(folds):
            assert not set(groups[tr])&set(groups[te])
            m,best=search_fit(target,X[tr],y[tr],groups[tr],20260907+100*TARGETS.index(target)+k,jobs)
            oof[te]=m.predict(X[te]);params.append({'fold':k+1,'best_params':best})
            for i in te:
                fold_rows.append({'record_id':train[i]['record_id'],'formula':groups[i],'fold':k+1,'target':target,'reference':y[i],'prediction':oof[i],'residual':y[i]-oof[i]})
            print(f'  fold {k+1}/5 finished',flush=True)
        m,best=search_fit(target,X,y,groups,20260907+9000+TARGETS.index(target),jobs)
        exported=export_model(m,OUTPUTS[target][3]);params.append({'fold':'final','best_params':best})
        rng=np.random.default_rng(4);a=rng.choice(len(X),100);b=rng.choice(len(X),100)
        check=np.vstack([X,Xh,(X[a]+X[b])/2])
        reference=m.predict(check)
        portable=np.array([predict_model(exported,row.tolist()) for row in check])
        difference=float(np.max(np.abs(portable-reference)))
        tolerance=3e-4 if target=='Y04' else 1e-8
        if difference>tolerance:raise AssertionError((target,'portable inference mismatch',difference))
        with gzip.open(ROOT/f'models/{target}.json.gz','wt',encoding='utf-8') as f:json.dump(exported,f,allow_nan=False,separators=(',',':'))
        joblib.dump(m,ROOT/f'training/{target}.joblib')
        yh=np.array([float(r[target]) for r in holdout]);ph=m.predict(Xh)
        write_csv(ROOT/f'reports/{target}_oof.csv',sorted(fold_rows,key=lambda r:r['record_id']))
        write_csv(ROOT/f'reports/{target}_validation.csv',[{
            'validation_id':r['validation_id'],'original_test_id':r['original_test_id'],'record_id':r['record_id'],'name':r['name'],
            'target':target,'reference':yh[i],'prediction':float(ph[i]),'residual':float(yh[i]-ph[i])} for i,r in enumerate(holdout)])
        manifest['metrics'][target]={'cv':metrics(y,oof),'validation':metrics(yh,ph)}
        manifest['models'][target]={'family':OUTPUTS[target][3],'fit_n':300,'best_params':best,
            'sha256':hashlib.sha256((ROOT/f'models/{target}.json.gz').read_bytes()).hexdigest(),
            'portable_parity_max_abs_error':difference,'portable_parity_cases':len(check),
            'trained_at_utc':datetime.now(timezone.utc).isoformat()}
        (ROOT/f'reports/{target}_parameters.json').write_text(json.dumps(params,indent=2),encoding='utf-8')
        (ROOT/'models/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        print(target,manifest['metrics'][target],'portable error',difference,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--targets',nargs='+',default=TARGETS);p.add_argument('--jobs',type=int,default=2)
    args=p.parse_args();run(args.targets,args.jobs)
